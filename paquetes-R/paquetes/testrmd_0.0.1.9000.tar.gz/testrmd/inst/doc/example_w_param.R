params <-
structure(list(test = FALSE), .Names = "test")

## ----setup, include = FALSE----------------------------------------------
testrmd::init()

## ----failing_test_true, test = TRUE--------------------------------------
library(assertthat)
assert_that(is.numeric(y))

