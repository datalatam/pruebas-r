library(testthat)
library(testrmd)

test_check("testrmd")
